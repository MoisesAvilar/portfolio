import icons from "../assets/icons";
import styles from "./Technologies.module.css";

const technologyCategories = [
  {
    category: "Backend",
    technologies: [
      { name: "Python", icon: icons.python },
      { name: "Django", icon: icons.django },
      { name: "Node.js", icon: icons.nodejs },
      { name: "PostgreSQL", icon: icons.postgresql },
      { name: "SQLite3", icon: icons.sqlite },
    ]
  },
  {
    category: "Frontend",
    technologies: [
      { name: "React", icon: icons.react },
      { name: "JavaScript", icon: icons.javascript },
      { name: "HTML5", icon: icons.html5 },
      { name: "CSS3", icon: icons.css3 },
    ]
  },
  {
    category: "Ferramentas e Outros",
    technologies: [
      { name: "Postman", icon: icons.postman },
      { name: "PySimpleGUI", icon: icons.pysimplegui },
      // Adicione aqui futuramente Git, Docker, etc.
    ]
  }
];

// ... (dentro do componente Technologies)

function Technologies() {
  return (
    <section id="technologies" className={styles.technologies} data-aos="fade-up">
      <h2 className={styles.title}>Minhas Habilidades</h2>
      <div className={styles.grid}>
        {technologyCategories.map((categoryGroup) => (
          // Usamos um Fragment para agrupar o título da categoria e seus ícones
          <> 
            {/* Título da Categoria */}
            <h3 className={styles.categoryTitle}>{categoryGroup.category}</h3>
            
            {/* Ícones da Categoria */}
            {categoryGroup.technologies.map((tech, index) => (
              <div key={index} className={styles.card}>
                <img 
                  src={tech.icon} 
                  alt={tech.name} 
                  className={styles.icon}
                  loading="lazy"
                />
                <span className={styles.name}>{tech.name}</span>
              </div>
            ))}
          </>
        ))}
      </div>
    </section>
  );
}

export default Technologies;