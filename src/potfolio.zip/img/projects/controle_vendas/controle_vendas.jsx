import foto1 from "../controle_vendas/foto1.jfif";
import foto2 from "../controle_vendas/foto2.jfif";

const controleVendasImgs = {
  controleVendasImg1: foto1,
  controleVendasImg2: foto2,
};

export default controleVendasImgs;
