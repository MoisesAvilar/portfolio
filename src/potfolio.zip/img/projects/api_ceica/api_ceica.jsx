import ceica from './ceica.png';
import ceica2 from './ceica2.png';
import ceica3 from './ceica3.png';

const ceicaImgs = {
    ceicaImg1: ceica,
    ceicaImg2: ceica2,
    ceicaImg3: ceica3,
}

export default ceicaImgs
