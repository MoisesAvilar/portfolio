import home from "../gerenciamento_financeiro/home-mobile.png";
import itemView from "../gerenciamento_financeiro/pc-item-view.png";
import lists from "../gerenciamento_financeiro/lists-tablet.png";

const gerenciamentoFinanceiroImgs = {
  gerenciamentoFinanceiroImg1: home,
  gerenciamentoFinanceiroImg2: lists,
  gerenciamentoFinanceiroImg3: itemView,
};

export default gerenciamentoFinanceiroImgs;
