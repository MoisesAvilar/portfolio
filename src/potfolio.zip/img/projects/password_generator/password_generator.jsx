import start_screen from "./start_screen.jpg";
import saving_password from "./saving_password.jpg";

const passwordGeneratorImgs = {
  passwordGeneratorImg1: start_screen,
  passwordGeneratorImg2: saving_password,
};

export default passwordGeneratorImgs;
